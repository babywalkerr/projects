#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Генератор больших CSV файлов с музыкальными треками
Создает файл data.csv размером более 1 ГБ
"""

import csv
import random
import time
from pathlib import Path

# Списки данных для генерации
ARTISTS = [
    "Travis Scott", "Drake", "The Weeknd", "Kendrick Lamar",
    "Post Malone", "21 Savage", "Future", "Playboi Carti",
    "Lil Uzi Vert", "Tyler, The Creator", "Kanye West", "J. Cole",
    "Metro Boomin", "Don Toliver", "Gunna", "Lil Baby"
]

ALBUMS = {
    "Travis Scott": ["UTOPIA", "Astroworld", "Rodeo", "Birds in the Trap"],
    "Drake": ["For All The Dogs", "Certified Lover Boy", "Scorpion", "Views"],
    "The Weeknd": ["After Hours", "Dawn FM", "Starboy", "Beauty Behind"],
    "Kendrick Lamar": ["Mr. Morale", "DAMN.", "good kid", "To Pimp"],
    "Post Malone": ["Austin", "Twelve Carat", "Hollywood's Bleeding"],
    "21 Savage": ["american dream", "Savage Mode II", "I Am > I Was"],
    "Future": ["I NEVER LIKED YOU", "DS2", "HNDRXX", "High Off Life"],
    "Playboi Carti": ["Whole Lotta Red", "Die Lit", "Playboi Carti"],
    "Lil Uzi Vert": ["Pink Tape", "Eternal Atake", "Luv Is Rage 2"],
    "Tyler, The Creator": ["Call Me If You Get Lost", "Igor", "Flower Boy"],
    "Kanye West": ["Donda", "Jesus Is King", "ye", "The Life of Pablo"],
    "J. Cole": ["The Off-Season", "KOD", "4 Your Eyez Only"],
    "Metro Boomin": ["Heroes & Villains", "NOT ALL HEROES WEAR CAPES"],
    "Don Toliver": ["Love Sick", "Heaven Or Hell", "Life of a Don"],
    "Gunna": ["a Gift & a Curse", "DS4EVER", "Wunna"],
    "Lil Baby": ["It's Only Me", "My Turn", "Harder Than Ever"]
}

# Префиксы для названий треков
TRACK_PREFIXES = [
    "FE!N", "Sicko Mode", "Nights", "HUMBLE.", "Rockstar", "Bank Account",
    "Mask Off", "Magnolia", "XO TOUR Llif3", "EARFQUAKE", "Stronger",
    "No Role Modelz", "Creepin", "After Party", "Drip Too Hard", "Woah"
]

# Суффиксы для разнообразия
TRACK_SUFFIXES = ["", " (feat. Drake)", " (Remix)", " [Extended]", " - Demo", 
                  " (Deluxe)", " - Live", " (Acoustic)", ""]


def generate_track_name():
    """Генерирует случайное название трека"""
    prefix = random.choice(TRACK_PREFIXES)
    suffix = random.choice(TRACK_SUFFIXES)
    # иногда добавляем цифры в конец
    if random.random() < 0.3:
        suffix += f" {random.randint(1, 9)}"
    return prefix + suffix


def generate_csv(filename="data.csv", target_size_gb=1.2):
    """
    Генерирует CSV файл с музыкальными данными
    
    Args:
        filename: имя выходного файла
        target_size_gb: целевой размер файла в ГБ
    """
    print(f"Начинаю генерацию файла {filename}...")
    print(f"Целевой размер: {target_size_gb} ГБ")
    
    start_time = time.time()
    target_size_bytes = target_size_gb * 1024 * 1024 * 1024
    current_size = 0
    rows_written = 0
    
    with open(filename, 'w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        
        # Заголовок
        header = ['track_id', 'artist', 'title', 'album', 'year', 
                  'duration_sec', 'plays', 'rating']
        writer.writerow(header)
        
        track_id = 10000
        
        # Генерируем строки пока не достигнем нужного размера
        while current_size < target_size_bytes:
            artist = random.choice(ARTISTS)
            title = generate_track_name()
            album = random.choice(ALBUMS.get(artist, ["Unknown Album"]))
            year = random.randint(2015, 2024)
            duration = random.randint(120, 300)  # 2-5 минут
            plays = random.randint(1000, 20000000)  # от 1к до 20млн
            rating = round(random.uniform(3.0, 5.0), 1)
            
            row = [track_id, artist, title, album, year, duration, plays, rating]
            writer.writerow(row)
            
            # Примерная оценка размера (не точная, но достаточная)
            current_size += len(','.join(map(str, row))) + 1
            
            track_id += 1
            rows_written += 1
            
            # Вывод прогресса каждые 100k строк
            if rows_written % 100000 == 0:
                size_mb = current_size / (1024 * 1024)
                elapsed = time.time() - start_time
                print(f"Записано строк: {rows_written:,} | "
                      f"Размер: {size_mb:.2f} МБ | "
                      f"Время: {elapsed:.1f}с")
    
    # Итоговая статистика
    final_size_mb = Path(filename).stat().st_size / (1024 * 1024)
    total_time = time.time() - start_time
    
    print(f"\n{'='*50}")
    print(f"Генерация завершена!")
    print(f"Файл: {filename}")
    print(f"Размер: {final_size_mb:.2f} МБ ({final_size_mb/1024:.2f} ГБ)")
    print(f"Строк: {rows_written:,}")
    print(f"Время генерации: {total_time:.1f} секунд")
    print(f"{'='*50}")


if __name__ == "__main__":
    # Генерируем файл ~1.2 ГБ
    generate_csv("data.csv", target_size_gb=1.2)
