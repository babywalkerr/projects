#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
GUI для демонстрации работы внешней сортировки
Позволяет генерировать файлы, сортировать и проверять результаты
"""

import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox, filedialog
import threading
import subprocess
import csv
from pathlib import Path
import sys
import os

# Добавляем текущую директорию в путь для импорта
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

try:
    from generator import generate_csv
    from external_sort import ExternalSort
except ImportError as e:
    print(f"Ошибка импорта: {e}")


class ExternalSortGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Внешняя сортировка больших файлов")
        self.root.geometry("900x700")
        
        # Переменные
        self.input_file = tk.StringVar(value="data.csv")
        self.output_file = tk.StringVar(value="sorted.txt")
        self.language = tk.StringVar(value="Python")
        self.sort_key = tk.StringVar(value="track_id")
        self.file_size = tk.DoubleVar(value=1.2)
        
        self.create_widgets()
    
    def create_widgets(self):
        # Фрейм для генерации файла
        gen_frame = ttk.LabelFrame(self.root, text="1. Генерация данных", padding=10)
        gen_frame.pack(fill="x", padx=10, pady=5)
        
        ttk.Label(gen_frame, text="Размер файла (ГБ):").grid(row=0, column=0, sticky="w")
        size_spin = ttk.Spinbox(gen_frame, from_=0.5, to=5.0, increment=0.1, 
                                textvariable=self.file_size, width=10)
        size_spin.grid(row=0, column=1, padx=5)
        
        gen_btn = ttk.Button(gen_frame, text="Сгенерировать data.csv", 
                            command=self.generate_file)
        gen_btn.grid(row=0, column=2, padx=10)
        
        # Фрейм для настроек сортировки
        sort_frame = ttk.LabelFrame(self.root, text="2. Настройки сортировки", padding=10)
        sort_frame.pack(fill="x", padx=10, pady=5)
        
        # Входной файл
        ttk.Label(sort_frame, text="Входной файл:").grid(row=0, column=0, sticky="w")
        ttk.Entry(sort_frame, textvariable=self.input_file, width=30).grid(row=0, column=1, padx=5)
        ttk.Button(sort_frame, text="Обзор...", command=self.browse_input).grid(row=0, column=2)
        
        # Выходной файл
        ttk.Label(sort_frame, text="Выходной файл:").grid(row=1, column=0, sticky="w", pady=5)
        ttk.Entry(sort_frame, textvariable=self.output_file, width=30).grid(row=1, column=1, padx=5)
        
        # Язык реализации
        ttk.Label(sort_frame, text="Язык:").grid(row=2, column=0, sticky="w")
        lang_frame = ttk.Frame(sort_frame)
        lang_frame.grid(row=2, column=1, sticky="w", padx=5)
        ttk.Radiobutton(lang_frame, text="Python", variable=self.language, 
                       value="Python").pack(side="left", padx=5)
        ttk.Radiobutton(lang_frame, text="C++", variable=self.language, 
                       value="C++").pack(side="left")
        
        # Ключ сортировки
        ttk.Label(sort_frame, text="Ключ сортировки:").grid(row=3, column=0, sticky="w", pady=5)
        keys = ['track_id', 'artist', 'title', 'album', 'year', 'duration_sec', 'plays', 'rating']
        key_combo = ttk.Combobox(sort_frame, textvariable=self.sort_key, values=keys, width=15)
        key_combo.grid(row=3, column=1, sticky="w", padx=5)
        
        # Кнопка сортировки
        sort_btn = ttk.Button(sort_frame, text="Запустить сортировку", 
                             command=self.run_sort, style="Accent.TButton")
        sort_btn.grid(row=4, column=0, columnspan=3, pady=10)
        
        # Фрейм для проверки результатов
        check_frame = ttk.LabelFrame(self.root, text="3. Проверка результатов", padding=10)
        check_frame.pack(fill="x", padx=10, pady=5)
        
        ttk.Button(check_frame, text="Показать начало файла", 
                  command=lambda: self.show_file_preview("start")).pack(side="left", padx=5)
        ttk.Button(check_frame, text="Показать конец файла", 
                  command=lambda: self.show_file_preview("end")).pack(side="left", padx=5)
        ttk.Button(check_frame, text="Проверить сортировку", 
                  command=self.check_sorted).pack(side="left", padx=5)
        
        # Лог
        log_frame = ttk.LabelFrame(self.root, text="Лог выполнения", padding=10)
        log_frame.pack(fill="both", expand=True, padx=10, pady=5)
        
        self.log_text = scrolledtext.ScrolledText(log_frame, height=20, width=80)
        self.log_text.pack(fill="both", expand=True)
        
        # Кнопка очистки лога
        ttk.Button(log_frame, text="Очистить лог", 
                  command=lambda: self.log_text.delete(1.0, tk.END)).pack(pady=5)
    
    def log(self, message):
        """Добавляет сообщение в лог"""
        self.log_text.insert(tk.END, message + "\n")
        self.log_text.see(tk.END)
        self.root.update()
    
    def browse_input(self):
        """Выбор входного файла"""
        filename = filedialog.askopenfilename(
            title="Выберите входной CSV файл",
            filetypes=[("CSV files", "*.csv"), ("All files", "*.*")]
        )
        if filename:
            self.input_file.set(filename)
    
    def generate_file(self):
        """Генерация тестового файла"""
        def generate_thread():
            try:
                self.log(f"Начинаю генерацию файла размером {self.file_size.get()} ГБ...")
                generate_csv("data.csv", self.file_size.get())
                self.log("Генерация завершена успешно!")
            except Exception as e:
                self.log(f"Ошибка при генерации: {e}")
        
        thread = threading.Thread(target=generate_thread, daemon=True)
        thread.start()
    
    def run_sort(self):
        """Запуск сортировки"""
        input_f = self.input_file.get()
        output_f = self.output_file.get()
        key = self.sort_key.get()
        lang = self.language.get()
        
        if not Path(input_f).exists():
            messagebox.showerror("Ошибка", f"Файл {input_f} не найден!")
            return
        
        def sort_thread():
            try:
                if lang == "Python":
                    self.log(f"\n{'='*60}")
                    self.log(f"Запуск Python сортировки...")
                    self.log(f"Файл: {input_f}")
                    self.log(f"Ключ: {key}")
                    self.log(f"{'='*60}\n")
                    
                    sorter = ExternalSort(input_f, output_f, key)
                    stats = sorter.sort()
                    
                    self.log(f"\nПитон сортировка завершена!")
                    self.log(f"Время: {stats['total_time']:.2f} сек")
                    
                else:  # C++
                    self.log(f"\n{'='*60}")
                    self.log(f"Запуск C++ сортировки...")
                    self.log(f"Файл: {input_f}")
                    self.log(f"Ключ: {key}")
                    self.log(f"{'='*60}\n")
                    
                    # Проверяем наличие скомпилированной программы
                    cpp_exe = Path("external_sort") if os.name != 'nt' else Path("external_sort.exe")
                    if not cpp_exe.exists():
                        self.log("Ошибка: C++ программа не скомпилирована!")
                        self.log("Сначала выполните: mkdir build && cd build && cmake .. && make")
                        return
                    
                    # Запускаем C++ программу
                    result = subprocess.run(
                        [str(cpp_exe), input_f, output_f, key],
                        capture_output=True,
                        text=True
                    )
                    
                    self.log(result.stdout)
                    if result.stderr:
                        self.log(f"Stderr: {result.stderr}")
                    
                    if result.returncode == 0:
                        self.log("\nC++ сортировка завершена!")
                    else:
                        self.log(f"\nОшибка выполнения (код {result.returncode})")
                        
            except Exception as e:
                self.log(f"Ошибка: {e}")
                import traceback
                self.log(traceback.format_exc())
        
        thread = threading.Thread(target=sort_thread, daemon=True)
        thread.start()
    
    def show_file_preview(self, position="start"):
        """Показывает предпросмотр файла"""
        output_f = self.output_file.get()
        
        if not Path(output_f).exists():
            messagebox.showwarning("Предупреждение", f"Файл {output_f} не найден!")
            return
        
        try:
            lines = []
            with open(output_f, 'r', encoding='utf-8') as f:
                if position == "start":
                    # Первые 20 строк
                    for i, line in enumerate(f):
                        if i >= 20:
                            break
                        lines.append(line.strip())
                else:
                    # Последние 20 строк
                    all_lines = f.readlines()
                    lines = [line.strip() for line in all_lines[-20:]]
            
            self.log(f"\n{'='*60}")
            self.log(f"Предпросмотр ({position}): {output_f}")
            self.log(f"{'='*60}")
            for line in lines:
                self.log(line)
            self.log(f"{'='*60}\n")
            
        except Exception as e:
            self.log(f"Ошибка при чтении файла: {e}")
    
    def check_sorted(self):
        """Проверяет правильность сортировки"""
        output_f = self.output_file.get()
        key = self.sort_key.get()
        
        if not Path(output_f).exists():
            messagebox.showwarning("Предупреждение", f"Файл {output_f} не найден!")
            return
        
        def check_thread():
            try:
                self.log(f"\nПроверка сортировки файла {output_f} по полю {key}...")
                
                with open(output_f, 'r', encoding='utf-8') as f:
                    reader = csv.reader(f)
                    header = next(reader)
                    
                    try:
                        key_index = header.index(key)
                    except ValueError:
                        self.log(f"Ошибка: поле {key} не найдено в заголовке")
                        return
                    
                    prev_value = None
                    is_sorted = True
                    errors = 0
                    checked = 0
                    
                    # Определяем тип поля
                    is_numeric = key in ['track_id', 'year', 'duration_sec', 'plays', 'rating']
                    
                    for row in reader:
                        if len(row) <= key_index:
                            continue
                        
                        value = row[key_index]
                        
                        # Преобразуем значение
                        if is_numeric:
                            try:
                                current = float(value)
                            except:
                                current = 0
                        else:
                            current = value.lower()
                        
                        if prev_value is not None and current < prev_value:
                            is_sorted = False
                            errors += 1
                            if errors <= 5:  # Показываем первые 5 ошибок
                                self.log(f"  Ошибка сортировки: {prev_value} > {current}")
                        
                        prev_value = current
                        checked += 1
                
                self.log(f"Проверено строк: {checked:,}")
                if is_sorted:
                    self.log("✓ Файл отсортирован правильно!")
                else:
                    self.log(f"✗ Найдено ошибок сортировки: {errors}")
                    
            except Exception as e:
                self.log(f"Ошибка при проверке: {e}")
        
        thread = threading.Thread(target=check_thread, daemon=True)
        thread.start()


def main():
    root = tk.Tk()
    app = ExternalSortGUI(root)
    root.mainloop()


if __name__ == "__main__":
    main()
