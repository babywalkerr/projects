#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Тестовый скрипт для проверки работоспособности внешней сортировки
Создает небольшой тестовый файл и проверяет сортировку
"""

import csv
import os
import subprocess
from pathlib import Path
import sys

# Добавляем текущую директорию в путь
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from external_sort import ExternalSort


def create_test_file(filename="test_data.csv", num_rows=10000):
    """Создает небольшой тестовый файл для проверки"""
    print(f"Создаю тестовый файл {filename} с {num_rows} строками...")
    
    import random
    
    artists = ["Travis Scott", "Drake", "The Weeknd", "Kendrick Lamar"]
    
    with open(filename, 'w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        writer.writerow(['track_id', 'artist', 'title', 'album', 'year', 
                        'duration_sec', 'plays', 'rating'])
        
        for i in range(num_rows):
            track_id = random.randint(1000, 99999)
            artist = random.choice(artists)
            title = f"Track {i}"
            album = f"Album {random.randint(1, 10)}"
            year = random.randint(2015, 2024)
            duration = random.randint(120, 300)
            plays = random.randint(1000, 1000000)
            rating = round(random.uniform(3.0, 5.0), 1)
            
            writer.writerow([track_id, artist, title, album, year, duration, plays, rating])
    
    print(f"✓ Файл {filename} создан")


def verify_sorted(filename, key='track_id'):
    """Проверяет правильность сортировки"""
    print(f"\nПроверка сортировки файла {filename} по ключу '{key}'...")
    
    with open(filename, 'r', encoding='utf-8') as f:
        reader = csv.reader(f)
        header = next(reader)
        
        try:
            key_index = header.index(key)
        except ValueError:
            print(f"✗ Ошибка: поле {key} не найдено!")
            return False
        
        is_numeric = key in ['track_id', 'year', 'duration_sec', 'plays', 'rating']
        
        prev_value = None
        for row_num, row in enumerate(reader, start=2):
            if len(row) <= key_index:
                continue
            
            value = row[key_index]
            
            # Преобразуем значение
            if is_numeric:
                try:
                    current = float(value)
                except:
                    current = 0
            else:
                current = value.lower()
            
            if prev_value is not None and current < prev_value:
                print(f"✗ Ошибка сортировки на строке {row_num}:")
                print(f"  {prev_value} > {current}")
                return False
            
            prev_value = current
    
    print(f"✓ Файл отсортирован корректно!")
    return True


def test_python_sort():
    """Тестирует Python версию"""
    print("\n" + "="*60)
    print("ТЕСТ PYTHON ВЕРСИИ")
    print("="*60)
    
    # Создаем тестовый файл
    test_input = "test_data.csv"
    test_output = "test_sorted_py.txt"
    
    create_test_file(test_input, 10000)
    
    # Запускаем сортировку
    print("\nЗапуск сортировки...")
    sorter = ExternalSort(test_input, test_output, 'track_id')
    stats = sorter.sort()
    
    # Проверяем результат
    if Path(test_output).exists():
        print(f"✓ Выходной файл создан")
        if verify_sorted(test_output, 'track_id'):
            print("\n✓✓✓ PYTHON ВЕРСИЯ РАБОТАЕТ КОРРЕКТНО ✓✓✓")
            result = True
        else:
            print("\n✗✗✗ ОШИБКА: ФАЙЛ НЕ ОТСОРТИРОВАН ✗✗✗")
            result = False
    else:
        print("✗ Выходной файл не создан!")
        result = False
    
    # Очистка
    for f in [test_input, test_output]:
        if Path(f).exists():
            Path(f).unlink()
    
    return result


def test_cpp_sort():
    """Тестирует C++ версию"""
    print("\n" + "="*60)
    print("ТЕСТ C++ ВЕРСИИ")
    print("="*60)
    
    # Проверяем наличие исполняемого файла
    cpp_exe = Path("build/external_sort")
    if not cpp_exe.exists():
        print("✗ C++ программа не найдена!")
        print("  Сначала выполните: bash build.sh")
        return False
    
    # Создаем тестовый файл
    test_input = "test_data.csv"
    test_output = "test_sorted_cpp.txt"
    
    create_test_file(test_input, 10000)
    
    # Запускаем сортировку
    print("\nЗапуск сортировки...")
    result = subprocess.run(
        [str(cpp_exe), test_input, test_output, "track_id"],
        capture_output=True,
        text=True
    )
    
    print(result.stdout)
    
    # Проверяем результат
    if result.returncode == 0 and Path(test_output).exists():
        print(f"✓ Выходной файл создан")
        if verify_sorted(test_output, 'track_id'):
            print("\n✓✓✓ C++ ВЕРСИЯ РАБОТАЕТ КОРРЕКТНО ✓✓✓")
            test_result = True
        else:
            print("\n✗✗✗ ОШИБКА: ФАЙЛ НЕ ОТСОРТИРОВАН ✗✗✗")
            test_result = False
    else:
        print("✗ Ошибка выполнения C++ программы!")
        if result.stderr:
            print(f"Stderr: {result.stderr}")
        test_result = False
    
    # Очистка
    for f in [test_input, test_output]:
        if Path(f).exists():
            Path(f).unlink()
    
    return test_result


def main():
    """Главная функция тестирования"""
    print("\n" + "="*60)
    print("ТЕСТИРОВАНИЕ ВНЕШНЕЙ СОРТИРОВКИ")
    print("="*60)
    
    results = {}
    
    # Тест Python версии
    results['python'] = test_python_sort()
    
    # Тест C++ версии
    results['cpp'] = test_cpp_sort()
    
    # Итоговый отчет
    print("\n" + "="*60)
    print("ИТОГОВЫЙ ОТЧЕТ")
    print("="*60)
    print(f"Python версия: {'✓ PASS' if results['python'] else '✗ FAIL'}")
    print(f"C++ версия:    {'✓ PASS' if results['cpp'] else '✗ FAIL (или не собрана)'}")
    print("="*60)
    
    if all(results.values()):
        print("\n🎉 ВСЕ ТЕСТЫ ПРОЙДЕНЫ!")
        return 0
    else:
        print("\n⚠️  НЕКОТОРЫЕ ТЕСТЫ НЕ ПРОЙДЕНЫ")
        return 1


if __name__ == "__main__":
    sys.exit(main())
