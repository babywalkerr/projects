#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Внешняя сортировка больших CSV файлов (Python реализация)
Использует алгоритм разбиения на блоки и k-путевого слияния
"""

import csv
import heapq
import os
import time
from pathlib import Path
from typing import List, Tuple


class ExternalSort:
    """Класс для выполнения внешней сортировки CSV файлов"""
    
    def __init__(self, input_file: str, output_file: str, sort_key: str = 'track_id'):
        """
        Args:
            input_file: путь к входному CSV файлу
            output_file: путь к выходному файлу
            sort_key: поле для сортировки
        """
        self.input_file = input_file
        self.output_file = output_file
        self.sort_key = sort_key
        self.temp_dir = Path("temp_chunks")
        self.chunk_files = []
        
        # Ограничение памяти (10% от размера файла)
        file_size = Path(input_file).stat().st_size
        self.memory_limit = file_size * 0.1  # байты
        print(f"Размер входного файла: {file_size / (1024**3):.2f} ГБ")
        print(f"Лимит памяти: {self.memory_limit / (1024**2):.2f} МБ")
    
    def _get_sort_key_index(self, header: List[str]) -> int:
        """Находит индекс поля для сортировки"""
        try:
            return header.index(self.sort_key)
        except ValueError:
            print(f"Ошибка: поле '{self.sort_key}' не найдено в заголовке")
            print(f"Доступные поля: {', '.join(header)}")
            raise
    
    def _parse_value(self, value: str, key_index: int, header: List[str]):
        """Преобразует значение в нужный тип для сортировки"""
        key_name = header[key_index]
        
        # Числовые поля
        if key_name in ['track_id', 'year', 'duration_sec', 'plays']:
            try:
                return int(value)
            except:
                return 0
        elif key_name == 'rating':
            try:
                return float(value)
            except:
                return 0.0
        else:
            # Строковые поля (artist, title, album)
            return value.lower()  # для регистронезависимой сортировки
    
    def split_into_chunks(self) -> float:
        """
        Разбивает входной файл на отсортированные блоки
        Returns: время выполнения в секундах
        """
        print("\n[Этап 1] Разбиение на блоки и сортировка...")
        start_time = time.time()
        
        # Создаем директорию для временных файлов
        self.temp_dir.mkdir(exist_ok=True)
        
        chunk_num = 0
        current_chunk = []
        current_size = 0
        # Берем размер блока немного меньше лимита для запаса
        chunk_size_limit = self.memory_limit * 0.8
        
        with open(self.input_file, 'r', encoding='utf-8') as f:
            reader = csv.reader(f)
            header = next(reader)
            key_index = self._get_sort_key_index(header)
            
            for row in reader:
                row_size = sum(len(field) for field in row) + len(row)
                
                # Если текущий блок переполнен - сохраняем его
                if current_size + row_size > chunk_size_limit and current_chunk:
                    self._save_sorted_chunk(current_chunk, chunk_num, header, key_index)
                    chunk_num += 1
                    current_chunk = []
                    current_size = 0
                
                current_chunk.append(row)
                current_size += row_size
            
            # Сохраняем последний блок
            if current_chunk:
                self._save_sorted_chunk(current_chunk, chunk_num, header, key_index)
                chunk_num += 1
        
        elapsed = time.time() - start_time
        print(f"Создано блоков: {len(self.chunk_files)}")
        print(f"Время разбиения: {elapsed:.2f} сек")
        
        return elapsed
    
    def _save_sorted_chunk(self, chunk: List[List[str]], chunk_num: int, 
                          header: List[str], key_index: int):
        """Сортирует и сохраняет блок во временный файл"""
        # Сортируем блок
        chunk.sort(key=lambda row: self._parse_value(row[key_index], key_index, header))
        
        # Сохраняем в файл
        chunk_file = self.temp_dir / f"chunk_{chunk_num:04d}.csv"
        with open(chunk_file, 'w', newline='', encoding='utf-8') as f:
            writer = csv.writer(f)
            writer.writerow(header)  # заголовок
            writer.writerows(chunk)
        
        self.chunk_files.append(chunk_file)
        print(f"  Сохранен блок {chunk_num}: {len(chunk)} строк")
    
    def merge_chunks(self) -> float:
        """
        Выполняет k-путевое слияние отсортированных блоков
        Returns: время выполнения в секундах
        """
        print(f"\n[Этап 2] Слияние {len(self.chunk_files)} блоков...")
        start_time = time.time()
        
        # Открываем все файлы блоков
        chunk_readers = []
        header = None
        key_index = None
        
        for chunk_file in self.chunk_files:
            f = open(chunk_file, 'r', encoding='utf-8')
            reader = csv.reader(f)
            h = next(reader)  # читаем заголовок
            if header is None:
                header = h
                key_index = self._get_sort_key_index(header)
            chunk_readers.append((reader, f))
        
        # Создаем выходной файл
        with open(self.output_file, 'w', newline='', encoding='utf-8') as out_f:
            writer = csv.writer(out_f)
            writer.writerow(header)
            
            # Инициализируем кучу (heap) для k-путевого слияния
            heap = []
            for idx, (reader, _) in enumerate(chunk_readers):
                try:
                    row = next(reader)
                    sort_value = self._parse_value(row[key_index], key_index, header)
                    # (значение_для_сортировки, индекс_блока, строка)
                    heapq.heappush(heap, (sort_value, idx, row))
                except StopIteration:
                    pass  # пустой блок
            
            # Выполняем слияние
            rows_merged = 0
            while heap:
                _, chunk_idx, row = heapq.heappop(heap)
                writer.writerow(row)
                rows_merged += 1
                
                # Выводим прогресс каждые 100k строк
                if rows_merged % 100000 == 0:
                    print(f"  Слито строк: {rows_merged:,}")
                
                # Читаем следующую строку из того же блока
                try:
                    next_row = next(chunk_readers[chunk_idx][0])
                    sort_value = self._parse_value(next_row[key_index], key_index, header)
                    heapq.heappush(heap, (sort_value, chunk_idx, next_row))
                except StopIteration:
                    pass  # блок закончился
        
        # Закрываем все файлы
        for _, f in chunk_readers:
            f.close()
        
        elapsed = time.time() - start_time
        print(f"Всего слито строк: {rows_merged:,}")
        print(f"Время слияния: {elapsed:.2f} сек")
        
        return elapsed
    
    def cleanup(self):
        """Удаляет временные файлы"""
        print("\n[Этап 3] Очистка временных файлов...")
        for chunk_file in self.chunk_files:
            try:
                chunk_file.unlink()
            except Exception as e:
                print(f"Ошибка при удалении {chunk_file}: {e}")
        
        try:
            self.temp_dir.rmdir()
            print("Временные файлы удалены")
        except Exception as e:
            print(f"Ошибка при удалении директории: {e}")
    
    def sort(self) -> dict:
        """
        Выполняет полную внешнюю сортировку
        Returns: статистика выполнения
        """
        print(f"\n{'='*60}")
        print(f"ВНЕШНЯЯ СОРТИРОВКА (Python)")
        print(f"Входной файл: {self.input_file}")
        print(f"Выходной файл: {self.output_file}")
        print(f"Ключ сортировки: {self.sort_key}")
        print(f"{'='*60}")
        
        total_start = time.time()
        
        # Этап 1: Разбиение на блоки
        split_time = self.split_into_chunks()
        
        # Этап 2: Слияние блоков
        merge_time = self.merge_chunks()
        
        # Этап 3: Очистка
        self.cleanup()
        
        total_time = time.time() - total_start
        
        # Итоговая статистика
        stats = {
            'split_time': split_time,
            'merge_time': merge_time,
            'total_time': total_time,
            'output_size_mb': Path(self.output_file).stat().st_size / (1024 * 1024)
        }
        
        print(f"\n{'='*60}")
        print(f"ИТОГОВАЯ СТАТИСТИКА")
        print(f"Время разбиения: {split_time:.2f} сек")
        print(f"Время слияния: {merge_time:.2f} сек")
        print(f"Общее время: {total_time:.2f} сек ({total_time/60:.2f} мин)")
        print(f"Размер выходного файла: {stats['output_size_mb']:.2f} МБ")
        print(f"{'='*60}\n")
        
        return stats


def main():
    """Главная функция для тестирования"""
    import argparse
    
    parser = argparse.ArgumentParser(description='Внешняя сортировка CSV файлов')
    parser.add_argument('input', help='Входной CSV файл')
    parser.add_argument('output', help='Выходной файл')
    parser.add_argument('--key', default='track_id', 
                       help='Поле для сортировки (по умолчанию: track_id)')
    
    args = parser.parse_args()
    
    if not Path(args.input).exists():
        print(f"Ошибка: файл {args.input} не найден!")
        return
    
    sorter = ExternalSort(args.input, args.output, args.key)
    sorter.sort()


if __name__ == "__main__":
    main()
