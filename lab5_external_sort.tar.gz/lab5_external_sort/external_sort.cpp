/*
 * Внешняя сортировка больших CSV файлов (C++ реализация)
 * Алгоритм: разбиение на блоки + k-путевое слияние
 */

#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>
#include <algorithm>
#include <queue>
#include <filesystem>
#include <chrono>
#include <cstring>

namespace fs = std::filesystem;
using namespace std;

// Структура для хранения строки CSV с ключом сортировки
struct CSVRow {
    vector<string> fields;
    string sort_key_str;
    double sort_key_num;
    bool is_numeric;
    
    bool operator<(const CSVRow& other) const {
        if (is_numeric) {
            return sort_key_num < other.sort_key_num;
        }
        return sort_key_str < other.sort_key_str;
    }
    
    bool operator>(const CSVRow& other) const {
        if (is_numeric) {
            return sort_key_num > other.sort_key_num;
        }
        return sort_key_str > other.sort_key_str;
    }
};

// Структура для элемента в куче при слиянии
struct HeapNode {
    CSVRow row;
    int chunk_index;
    
    bool operator>(const HeapNode& other) const {
        return row > other.row;
    }
};

class ExternalSort {
private:
    string input_file;
    string output_file;
    string sort_key;
    fs::path temp_dir;
    vector<fs::path> chunk_files;
    vector<string> header;
    int key_index;
    size_t memory_limit;
    bool is_numeric_key;
    
    // Парсинг CSV строки
    vector<string> parse_csv_line(const string& line) {
        vector<string> fields;
        string field;
        bool in_quotes = false;
        
        for (char c : line) {
            if (c == '"') {
                in_quotes = !in_quotes;
            } else if (c == ',' && !in_quotes) {
                fields.push_back(field);
                field.clear();
            } else {
                field += c;
            }
        }
        fields.push_back(field);
        return fields;
    }
    
    // Формирование CSV строки
    string make_csv_line(const vector<string>& fields) {
        string line;
        for (size_t i = 0; i < fields.size(); i++) {
            if (i > 0) line += ',';
            line += fields[i];
        }
        return line;
    }
    
    // Определение индекса ключа сортировки
    int find_key_index(const vector<string>& header) {
        for (size_t i = 0; i < header.size(); i++) {
            if (header[i] == sort_key) {
                return i;
            }
        }
        cerr << "Ошибка: поле '" << sort_key << "' не найдено!" << endl;
        exit(1);
    }
    
    // Проверка, является ли ключ числовым
    bool check_numeric_key(const string& key_name) {
        return (key_name == "track_id" || key_name == "year" || 
                key_name == "duration_sec" || key_name == "plays" || 
                key_name == "rating");
    }
    
    // Извлечение значения ключа
    void extract_sort_key(CSVRow& row) {
        string value = row.fields[key_index];
        row.is_numeric = is_numeric_key;
        
        if (is_numeric_key) {
            try {
                row.sort_key_num = stod(value);
            } catch (...) {
                row.sort_key_num = 0;
            }
        } else {
            // Для строковых - приводим к нижнему регистру
            row.sort_key_str = value;
            transform(row.sort_key_str.begin(), row.sort_key_str.end(), 
                     row.sort_key_str.begin(), ::tolower);
        }
    }
    
    // Сохранение отсортированного блока
    void save_sorted_chunk(vector<CSVRow>& chunk, int chunk_num) {
        // Сортируем блок
        sort(chunk.begin(), chunk.end());
        
        // Сохраняем в файл
        char filename[256];
        sprintf(filename, "chunk_%04d.csv", chunk_num);
        fs::path chunk_path = temp_dir / filename;
        
        ofstream file(chunk_path);
        if (!file.is_open()) {
            cerr << "Ошибка создания файла: " << chunk_path << endl;
            return;
        }
        
        // Записываем заголовок
        file << make_csv_line(header) << "\n";
        
        // Записываем данные
        for (const auto& row : chunk) {
            file << make_csv_line(row.fields) << "\n";
        }
        
        file.close();
        chunk_files.push_back(chunk_path);
        
        cout << "  Сохранен блок " << chunk_num << ": " << chunk.size() << " строк" << endl;
    }
    
public:
    ExternalSort(const string& in_file, const string& out_file, const string& key)
        : input_file(in_file), output_file(out_file), sort_key(key), temp_dir("temp_chunks") {
        
        // Получаем размер файла
        size_t file_size = fs::file_size(input_file);
        memory_limit = (size_t)(file_size * 0.1);  // 10% от размера файла
        
        cout << "Размер входного файла: " << (file_size / (1024.0 * 1024 * 1024)) << " ГБ" << endl;
        cout << "Лимит памяти: " << (memory_limit / (1024.0 * 1024)) << " МБ" << endl;
    }
    
    // Этап 1: Разбиение на блоки
    double split_into_chunks() {
        cout << "\n[Этап 1] Разбиение на блоки и сортировка..." << endl;
        auto start = chrono::high_resolution_clock::now();
        
        // Создаем директорию для временных файлов
        fs::create_directories(temp_dir);
        
        ifstream file(input_file);
        if (!file.is_open()) {
            cerr << "Ошибка открытия файла: " << input_file << endl;
            exit(1);
        }
        
        // Читаем заголовок
        string line;
        getline(file, line);
        header = parse_csv_line(line);
        key_index = find_key_index(header);
        is_numeric_key = check_numeric_key(sort_key);
        
        int chunk_num = 0;
        vector<CSVRow> current_chunk;
        size_t current_size = 0;
        size_t chunk_size_limit = (size_t)(memory_limit * 0.8);
        
        while (getline(file, line)) {
            if (line.empty()) continue;
            
            CSVRow row;
            row.fields = parse_csv_line(line);
            extract_sort_key(row);
            
            size_t row_size = line.size();
            
            // Если блок переполнен - сохраняем
            if (current_size + row_size > chunk_size_limit && !current_chunk.empty()) {
                save_sorted_chunk(current_chunk, chunk_num);
                chunk_num++;
                current_chunk.clear();
                current_size = 0;
            }
            
            current_chunk.push_back(row);
            current_size += row_size;
        }
        
        // Сохраняем последний блок
        if (!current_chunk.empty()) {
            save_sorted_chunk(current_chunk, chunk_num);
        }
        
        file.close();
        
        auto end = chrono::high_resolution_clock::now();
        double elapsed = chrono::duration<double>(end - start).count();
        
        cout << "Создано блоков: " << chunk_files.size() << endl;
        cout << "Время разбиения: " << elapsed << " сек" << endl;
        
        return elapsed;
    }
    
    // Этап 2: Слияние блоков
    double merge_chunks() {
        cout << "\n[Этап 2] Слияние " << chunk_files.size() << " блоков..." << endl;
        auto start = chrono::high_resolution_clock::now();
        
        // Открываем все файлы блоков
        vector<ifstream> chunk_streams;
        chunk_streams.reserve(chunk_files.size());
        
        for (const auto& chunk_file : chunk_files) {
            chunk_streams.emplace_back(chunk_file);
            if (!chunk_streams.back().is_open()) {
                cerr << "Ошибка открытия блока: " << chunk_file << endl;
                exit(1);
            }
            // Пропускаем заголовок
            string header_line;
            getline(chunk_streams.back(), header_line);
        }
        
        // Создаем выходной файл
        ofstream out_file(output_file);
        if (!out_file.is_open()) {
            cerr << "Ошибка создания выходного файла: " << output_file << endl;
            exit(1);
        }
        
        // Записываем заголовок
        out_file << make_csv_line(header) << "\n";
        
        // Инициализируем кучу для k-путевого слияния
        priority_queue<HeapNode, vector<HeapNode>, greater<HeapNode>> heap;
        
        string line;
        for (size_t i = 0; i < chunk_streams.size(); i++) {
            if (getline(chunk_streams[i], line)) {
                CSVRow row;
                row.fields = parse_csv_line(line);
                extract_sort_key(row);
                
                HeapNode node{row, (int)i};
                heap.push(node);
            }
        }
        
        // Выполняем слияние
        long long rows_merged = 0;
        while (!heap.empty()) {
            HeapNode node = heap.top();
            heap.pop();
            
            out_file << make_csv_line(node.row.fields) << "\n";
            rows_merged++;
            
            if (rows_merged % 100000 == 0) {
                cout << "  Слито строк: " << rows_merged << endl;
            }
            
            // Читаем следующую строку из того же блока
            if (getline(chunk_streams[node.chunk_index], line)) {
                CSVRow row;
                row.fields = parse_csv_line(line);
                extract_sort_key(row);
                
                HeapNode new_node{row, node.chunk_index};
                heap.push(new_node);
            }
        }
        
        // Закрываем файлы
        for (auto& stream : chunk_streams) {
            stream.close();
        }
        out_file.close();
        
        auto end = chrono::high_resolution_clock::now();
        double elapsed = chrono::duration<double>(end - start).count();
        
        cout << "Всего слито строк: " << rows_merged << endl;
        cout << "Время слияния: " << elapsed << " сек" << endl;
        
        return elapsed;
    }
    
    // Очистка временных файлов
    void cleanup() {
        cout << "\n[Этап 3] Очистка временных файлов..." << endl;
        
        for (const auto& chunk_file : chunk_files) {
            try {
                fs::remove(chunk_file);
            } catch (const exception& e) {
                cerr << "Ошибка при удалении " << chunk_file << ": " << e.what() << endl;
            }
        }
        
        try {
            fs::remove(temp_dir);
            cout << "Временные файлы удалены" << endl;
        } catch (const exception& e) {
            cerr << "Ошибка при удалении директории: " << e.what() << endl;
        }
    }
    
    // Полная сортировка
    void sort() {
        cout << "\n============================================================" << endl;
        cout << "ВНЕШНЯЯ СОРТИРОВКА (C++)" << endl;
        cout << "Входной файл: " << input_file << endl;
        cout << "Выходной файл: " << output_file << endl;
        cout << "Ключ сортировки: " << sort_key << endl;
        cout << "============================================================" << endl;
        
        auto total_start = chrono::high_resolution_clock::now();
        
        // Этап 1: Разбиение
        double split_time = split_into_chunks();
        
        // Этап 2: Слияние
        double merge_time = merge_chunks();
        
        // Этап 3: Очистка
        cleanup();
        
        auto total_end = chrono::high_resolution_clock::now();
        double total_time = chrono::duration<double>(total_end - total_start).count();
        
        // Статистика
        size_t output_size = fs::file_size(output_file);
        
        cout << "\n============================================================" << endl;
        cout << "ИТОГОВАЯ СТАТИСТИКА" << endl;
        cout << "Время разбиения: " << split_time << " сек" << endl;
        cout << "Время слияния: " << merge_time << " сек" << endl;
        cout << "Общее время: " << total_time << " сек (" 
             << (total_time / 60) << " мин)" << endl;
        cout << "Размер выходного файла: " << (output_size / (1024.0 * 1024)) << " МБ" << endl;
        cout << "============================================================\n" << endl;
    }
};

int main(int argc, char* argv[]) {
    if (argc < 3) {
        cout << "Использование: " << argv[0] << " <input.csv> <output.txt> [sort_key]" << endl;
        cout << "Пример: " << argv[0] << " data.csv sorted.txt track_id" << endl;
        return 1;
    }
    
    string input = argv[1];
    string output = argv[2];
    string key = (argc >= 4) ? argv[3] : "track_id";
    
    if (!fs::exists(input)) {
        cerr << "Ошибка: файл " << input << " не найден!" << endl;
        return 1;
    }
    
    ExternalSort sorter(input, output, key);
    sorter.sort();
    
    return 0;
}
