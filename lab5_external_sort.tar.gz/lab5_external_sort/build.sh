#!/bin/bash
# Скрипт для сборки C++ версии внешней сортировки

echo "=========================================="
echo "Сборка C++ версии external_sort"
echo "=========================================="

# Создаем директорию для сборки
if [ ! -d "build" ]; then
    echo "Создаю директорию build..."
    mkdir build
fi

cd build

# Запускаем CMake
echo "Конфигурация через CMake..."
cmake .. -DCMAKE_BUILD_TYPE=Release

if [ $? -ne 0 ]; then
    echo "Ошибка: CMake завершился с ошибкой!"
    exit 1
fi

# Компиляция
echo "Компиляция..."
make -j$(nproc)

if [ $? -ne 0 ]; then
    echo "Ошибка: компиляция не удалась!"
    exit 1
fi

cd ..

echo ""
echo "=========================================="
echo "Сборка завершена успешно!"
echo "Исполняемый файл: build/external_sort"
echo "=========================================="
echo ""
echo "Примеры использования:"
echo "  ./build/external_sort data.csv sorted.txt track_id"
echo "  ./build/external_sort data.csv sorted.txt artist"
echo ""
